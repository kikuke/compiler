int main(void) {
    typedef struct a {
        int b;
    } c;
    c z;
}