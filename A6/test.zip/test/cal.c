int main(void) {
    int a;
    int b;
    scanf("%d %d", &a, &b);
    printf("result: %d\n", a+b);
}