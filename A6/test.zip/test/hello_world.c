int main() {
    printf("hello world!");
}