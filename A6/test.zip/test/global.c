int a;

int main(void) {
    printf("1. %d", a);
    a = 10;
    printf("2. %d", a);
}